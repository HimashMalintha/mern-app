import React, { useState } from 'react';
import axios from 'axios';
import '../styles/AddMemberForm.css'; // Scoped CSS file for this form

function AddMemberForm({ onSwitchToDashboard }) {
  const [name, setName] = useState('');
  const [membershipType, setMembershipType] = useState('');
  const [status, setStatus] = useState('');
  const [joinDate, setJoinDate] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/api/members', {
        name,
        membershipType,
        status,
        joinDate,
      });
      setSuccess(response.data.message);
      setError('');
      setName('');
      setMembershipType('');
      setStatus('');
      setJoinDate('');

      // Redirect back to the dashboard after 2 seconds
      setTimeout(onSwitchToDashboard, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add member.');
    }
  };

  return (
    <div className="add-member-form-container">
      <form className="add-member-form" onSubmit={handleSubmit}>
        <h2>Add Member</h2>
        {success && <p className="success-message">{success}</p>}
        {error && <p className="error-message">{error}</p>}
        
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <label>Membership Type</label>
          <select
            value={membershipType}
            onChange={(e) => setMembershipType(e.target.value)}
            required
          >
            <option value="" disabled>Select Membership Type</option>
            <option value="Basic">Basic</option>
            <option value="Premium">Premium</option>
            <option value="VIP">VIP</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Status</label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            required
          >
            <option value="" disabled>Select Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Join Date</label>
          <input
            type="date"
            value={joinDate}
            onChange={(e) => setJoinDate(e.target.value)}
            required
          />
        </div>
        
        <button type="submit">Add Member</button>
        <button type="button" onClick={onSwitchToDashboard}>
          Cancel
        </button>
      </form>
    </div>
  );
}

export default AddMemberForm;
