import React, { useEffect, useState } from 'react';
import '../styles/MemberDashboard.css';

function MemberDashboard() {
  const [loginDate, setLoginDate] = useState('');

  useEffect(() => {
    // Get the current date
    const currentDate = new Date();
    // Format the date as "MMM DD, YYYY" (e.g., "Jan 03, 2025")
    const options = { year: 'numeric', month: 'short', day: '2-digit' };
    const formattedDate = currentDate.toLocaleDateString('en-US', options);
    setLoginDate(formattedDate);
  }, []); // Runs only once when the component is mounted

  return (
    <div className="member-dashboard-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <img src="/Logo.png" alt="Logo" className="logo-icon" />
        </div>
        <div className="sidebar-links">
          <button className="sidebar-button active" aria-label="Home">
            <i className="fas fa-home"></i>
          </button>
          <button className="sidebar-button" aria-label="Profile">
            <i className="fas fa-user"></i>
          </button>
          <button className="sidebar-button" aria-label="Settings">
            <i className="fas fa-cogs"></i>
          </button>
        </div>
        <div className="sidebar-profile">
          <img
            src="/profile-pic.jpg"
            alt="Profile"
            className="profile-picture"
            onError={(e) => (e.target.src = '/default-profile.jpg')} // Fallback image
          />
        </div>
      </aside>

      {/* Main Content */}
      <main className="dashboard-content">
        <header className="dashboard-header">
          <h1>Dashboard</h1>
          {/* Display the login date */}
          <p>{loginDate}</p>
          <span className="membership-level">GOLD MEMBER</span>
        </header>

        {/* Member Information */}
        <section className="member-info">
          <p className="since">Since 13 Nov, 2023</p>
          <h2 className="member-name">JOHN DOE</h2>
          <p className="member-email">johndoe@example.com</p>
        </section>
      </main>
    </div>
  );
}

export default MemberDashboard;
