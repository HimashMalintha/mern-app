import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AddClassForm from './AddClassForm'; // Import the AddClassForm component
import AdminTrainers from './AdminTrainers'; // Import the AdminTrainers component
import '../styles/AdminDashboard.css';

function AdminDashboard({ onSwitchToAddPlan, onSwitchToAddTrainers, onSwitchToAddMembers }) {
  const [memberCount, setMemberCount] = useState(0);
  const [trainerCount, setTrainerCount] = useState(0);
  const [currentView, setCurrentView] = useState('dashboard'); // State to track current view

  useEffect(() => {
    const fetchMemberCount = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/stats/members');
        setMemberCount(response.data.count);
      } catch (error) {
        console.error('Error fetching member count:', error);
      }
    };

    const fetchTrainerCount = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/stats/trainers');
        setTrainerCount(response.data.count);
      } catch (error) {
        console.error('Error fetching trainer count:', error);
      }
    };

    fetchMemberCount();
    fetchTrainerCount();
  }, []);

  // Function to render the appropriate view
  const renderView = () => {
    if (currentView === 'add-classes') {
      return <AddClassForm onSwitchToDashboard={() => setCurrentView('dashboard')} />;
    }

    if (currentView === 'trainer-list') {
      return <AdminTrainers onSwitchToDashboard={() => setCurrentView('dashboard')} />;
    }

    return (
      <main className="dashboard-content">
        {/* Header */}
        <header className="dashboard-header">
          <h1>Dashboard</h1>
          <p>
            {new Date().toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: '2-digit',
            })}
          </p>
          <p className="revenue">
            Last Month: <span className="revenue-amount">218,740.00 LKR</span>
          </p>
        </header>

        {/* Statistics */}
        <section className="dashboard-stats">
          <div className="stat-card">
            <p>Total Members</p>
            <h2>{memberCount}</h2>
          </div>
          <div className="stat-card">
            <p>Total Trainers</p>
            <h2>{trainerCount}</h2>
          </div>
        </section>

        {/* Logo and Action Buttons */}
        <section className="dashboard-actions">
          <div className="dashboard-logo">
            <img src="/Logo.png" alt="Minator Logo" />
            <h2>MINATOR</h2>
          </div>
          <div className="action-buttons">
            <button className="action-button" onClick={onSwitchToAddPlan}>
              Add Plans
            </button>
            <button className="action-button" onClick={() => setCurrentView('add-classes')}>
              Add Classes
            </button>
            <button className="action-button" onClick={onSwitchToAddTrainers}>
              Add Trainers
            </button>
            <button className="action-button" onClick={onSwitchToAddMembers}>
              Add Members
            </button>
            <button className="action-button" onClick={() => setCurrentView('trainer-list')}>
              Trainer List
            </button>
          </div>
        </section>
      </main>
    );
  };

  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <img src="/Logo.png" alt="Logo" className="logo-icon" />
        </div>
        <div className="sidebar-links">
          <button
            className={`sidebar-button ${currentView === 'dashboard' ? 'active' : ''}`}
            onClick={() => setCurrentView('dashboard')}
          >
            <i className="fas fa-home"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-user"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-users"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-cogs"></i>
          </button>
        </div>
        <div className="sidebar-profile">
          <img src="/profile-pic.jpg" alt="Profile" className="profile-picture" />
        </div>
      </aside>

      {/* Main Content */}
      {renderView()}
    </div>
  );
}

export default AdminDashboard;
