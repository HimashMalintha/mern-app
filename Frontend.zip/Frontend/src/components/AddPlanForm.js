import React, { useState } from 'react';
import axios from 'axios';
import '../styles/AddPlanForm.css';

function AddPlanForm({ onSwitchToDashboard }) {
  const [planName, setPlanName] = useState('');
  const [price, setPrice] = useState('');
  const [duration, setDuration] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const packageData = {
      planName,
      price,
      duration,
      description,
    };

    try {
      // Post data to the backend API
      const response = await axios.post('http://localhost:5000/api/packages', packageData);

      setSuccess(response.data.message);
      setError('');
      setPlanName('');
      setPrice('');
      setDuration('');
      setDescription('');

      // Redirect back to the dashboard after 2 seconds
      setTimeout(onSwitchToDashboard, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create package. Please try again.');
    }
  };

  return (
    <div className="add-plan-form-container">
      <form className="add-plan-form" onSubmit={handleSubmit}>
        <h2>Add Plan</h2>
        {success && <p className="success-message">{success}</p>}
        {error && <p className="error-message">{error}</p>}
        <div className="form-group">
          <label>Plan Name</label>
          <input
            type="text"
            value={planName}
            onChange={(e) => setPlanName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Price</label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Duration</label>
          <select
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            required
          >
            <option value="" disabled>
              Select Duration
            </option>
            <option value="Monthly">Monthly</option>
            <option value="Yearly">Yearly</option>
          </select>
        </div>
        <div className="form-group">
          <label>Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          ></textarea>
        </div>
        <button type="submit">Submit</button>
        <button type="button" onClick={onSwitchToDashboard}>
          Cancel
        </button>
      </form>
    </div>
  );
}

export default AddPlanForm;
