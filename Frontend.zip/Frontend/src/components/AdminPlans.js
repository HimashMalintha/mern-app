import React from 'react';
import '../styles/AdminPlans.css';

function AdminPlans() {
  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <img src="/Logo.png" alt="Logo" className="logo-icon" />
        </div>
        <div className="sidebar-links">
          <button className="sidebar-button active">
            <i className="fas fa-home"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-user"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-users"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-cogs"></i>
          </button>
        </div>
        <div className="sidebar-profile">
          <img src="/profile-pic.jpg" alt="Profile" className="profile-picture" />
        </div>
      </aside>

      {/* Main Content */}
      <main className="dashboard-content">
        <header className="dashboard-header">
          <h1>Plans & Classes</h1>
          <p>Jan 03, 2025</p>
        </header>

        {/* Plans Section */}
        <section className="plans-section">
          <h2>Plans</h2>
          <div className="plans">
            <div className="plan-card">
              <img src="/Logo.png" alt="Plan Logo" className="plan-logo" />
              <h3>Member</h3>
              <p className="plan-price">2000 LKR</p>
            </div>
            <div className="plan-card">
              <img src="/Logo.png" alt="Plan Logo" className="plan-logo" />
              <h3>Plus</h3>
              <p className="plan-price">2000 LKR</p>
            </div>
            <div className="plan-card">
              <img src="/Logo.png" alt="Plan Logo" className="plan-logo" />
              <h3>Gold</h3>
              <p className="plan-price">2000 LKR</p>
            </div>
          </div>
        </section>

        {/* Classes Section */}
        <section className="classes-section">
          <h2>Classes</h2>
          <div className="classes">
            <div className="class-card">
              <h3>Beginner BOX FIT</h3>
              <p>Saturday</p>
              <p>2:00 PM - 5:00 PM</p>
            </div>
            <div className="class-card">
              <h3>Beginner BOX FIT</h3>
              <p>Saturday</p>
              <p>2:00 PM - 5:00 PM</p>
            </div>
            <div className="class-card">
              <h3>Beginner BOX FIT</h3>
              <p>Saturday</p>
              <p>2:00 PM - 5:00 PM</p>
            </div>
            <div className="class-card">
              <h3>Beginner BOX FIT</h3>
              <p>Saturday</p>
              <p>2:00 PM - 5:00 PM</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default AdminPlans;
