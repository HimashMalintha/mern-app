import React, { useState } from "react";
import "../styles/Login.css";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { getFirestore, doc, getDoc } from "firebase/firestore";

function Login({ onSwitchToSignUp, onLoginSuccess }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const auth = getAuth();
  const db = getFirestore();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate email and password fields
    if (!email || !password) {
      setError("Please enter both email and password.");
      return;
    }

    try {
      // Authenticate user with Firebase Authentication
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );
      const user = userCredential.user;

      // Fetch user role from Firestore
      const userDoc = await getDoc(doc(db, "users", user.uid));
      if (userDoc.exists()) {
        const userRole = userDoc.data().role;

        // Navigate based on user role
        if (userRole === "admin") {
          onLoginSuccess("admin");
        } else if (userRole === "trainer") {
          onLoginSuccess("trainer");
        } else {
          // Navigate to MemberDashboard if role is not recognized
          onLoginSuccess("member");
        }
      } else {
        // Navigate to MemberDashboard if no role is found in the database
        onLoginSuccess("member");
      }
    } catch (firebaseError) {
      // Handle Firebase authentication errors
      if (firebaseError.code === "auth/user-not-found") {
        setError("No user found with this email.");
      } else if (firebaseError.code === "auth/wrong-password") {
        setError("Incorrect password. Please try again.");
      } else {
        setError(firebaseError.message);
      }
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2 className="login-title">Login</h2>

        {/* Email Input */}
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="form-input"
          />
        </div>

        {/* Password Input */}
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <div className="password-container">
            <input
              type={showPassword ? "text" : "password"}
              id="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-input"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="show-password-button"
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
        </div>

        {/* Error Message */}
        {error && <p className="error-message">{error}</p>}

        {/* Submit Button */}
        <button type="submit" className="login-button">
          Login
        </button>

        {/* Navigation to SignUp */}
        <p className="switch-page">
          Don't have an account?{" "}
          <button
            type="button"
            onClick={onSwitchToSignUp}
            className="link-button"
          >
            Sign Up
          </button>
        </p>
      </form>
    </div>
  );
}

export default Login;
