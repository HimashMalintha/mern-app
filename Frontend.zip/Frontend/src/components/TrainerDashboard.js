import React from 'react';
import '../styles/TrainerDashboard.css';

function TrainerDashboard() {
  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <img src="/Logo.png" alt="Logo" className="logo-icon" />
        </div>
        <div className="sidebar-links">
          <button className="sidebar-button active">
            <i className="fas fa-home"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-user"></i>
          </button>
          <button className="sidebar-button">
            <i className="fas fa-cogs"></i>
          </button>
        </div>
        <div className="sidebar-profile">
          <img src="/profile-pic.jpg" alt="Profile" className="profile-picture" />
        </div>
      </aside>

      {/* Main Content */}
      <main className="dashboard-content">
        <header className="dashboard-header">
          <h1>Dashboard</h1>
          <p>Jan 03, 2025</p>
          <span className="role">TRAINER</span>
        </header>

        {/* Trainer Information */}
        <section className="trainer-info">
          <p className="since">Since 15 Nov, 2022</p>
          <h2 className="trainer-name">JHON DOE</h2>
          <p className="trainer-role">BOX FIT</p>
          <p className="trainer-email">johndoe@example.com</p>
        </section>

        {/* Classes */}
        <section className="classes-section">
          <div className="class-card">
            <h3>Beginner BOX FIT</h3>
            <p>Saturday</p>
            <p>2:00 PM - 5:00 PM</p>
          </div>
          <div className="class-card">
            <h3>Intermediate BOX FIT</h3>
            <p>Saturday</p>
            <p>2:00 PM - 5:00 PM</p>
          </div>
          <div className="class-card">
            <h3>Advanced BOX FIT</h3>
            <p>Saturday</p>
            <p>2:00 PM - 5:00 PM</p>
          </div>
        </section>
      </main>
    </div>
  );
}

export default TrainerDashboard;
