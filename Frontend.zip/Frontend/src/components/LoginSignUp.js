import React from 'react';
import '../styles/LoginSignUp.css';

function LoginSignUp({ onSwitchToLogin, onSwitchToSignUp }) {
  return (
    <div className="login-signup-container">
      <div className="logo"></div>
      <div className="logo-text">MINATOR</div>
      <div className="buttons">
        <button className="button" onClick={onSwitchToLogin}>
          Sign In
        </button>
        <button className="button" onClick={onSwitchToSignUp}>
          Sign Up
        </button>
      </div>
    </div>
  );
}

export default LoginSignUp;
