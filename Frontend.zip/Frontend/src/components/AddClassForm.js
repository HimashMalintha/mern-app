import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { db } from '../firebaseConfig'; // Ensure Firestore instance is correctly imported
import '../styles/AddClassForm.css'; // Create styles specifically for this form

function AddClassForm({ onSwitchToDashboard }) {
  const [className, setClassName] = useState('');
  const [trainers, setTrainers] = useState([]);
  const [members, setMembers] = useState([]);
  const [selectedTrainer, setSelectedTrainer] = useState('');
  const [selectedMember, setSelectedMember] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch trainers from Firestore
    const fetchTrainers = async () => {
      try {
        const trainersSnapshot = await getDocs(collection(db, 'trainers'));
        const trainersData = trainersSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setTrainers(trainersData);
      } catch (err) {
        setError('Failed to fetch trainers.');
      }
    };

    // Fetch members from Firestore
    const fetchMembers = async () => {
      try {
        const membersSnapshot = await getDocs(collection(db, 'members'));
        const membersData = membersSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setMembers(membersData);
      } catch (err) {
        setError('Failed to fetch members.');
      }
    };

    fetchTrainers();
    fetchMembers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!className || !selectedTrainer || !selectedMember) {
      setError('Please fill in all fields.');
      return;
    }

    const classData = {
      className,
      trainer: selectedTrainer,
      member: selectedMember,
      createdAt: new Date().toISOString(),
    };

    try {
      await addDoc(collection(db, 'classes'), classData);
      setSuccess('Class added successfully!');
      setError('');
      setClassName('');
      setSelectedTrainer('');
      setSelectedMember('');
      setTimeout(onSwitchToDashboard, 2000);
    } catch (err) {
      setError('Failed to add class. Please try again.');
    }
  };

  return (
    <div className="add-class-form-container">
      <form className="add-class-form" onSubmit={handleSubmit}>
        <h2>Add Class</h2>
        {success && <p className="success-message">{success}</p>}
        {error && <p className="error-message">{error}</p>}
        
        {/* Class Name Input */}
        <div className="form-group">
          <label>Class Name</label>
          <input
            type="text"
            value={className}
            onChange={(e) => setClassName(e.target.value)}
            required
          />
        </div>

        {/* Trainer Dropdown */}
        <div className="form-group">
          <label>Trainer Name</label>
          <select
            value={selectedTrainer}
            onChange={(e) => setSelectedTrainer(e.target.value)}
            required
          >
            <option value="" disabled>
              Select a Trainer
            </option>
            {trainers.map((trainer) => (
              <option key={trainer.id} value={trainer.name}>
                {trainer.name}
              </option>
            ))}
          </select>
        </div>

        {/* Member Dropdown */}
        <div className="form-group">
          <label>Member Name</label>
          <select
            value={selectedMember}
            onChange={(e) => setSelectedMember(e.target.value)}
            required
          >
            <option value="" disabled>
              Select a Member
            </option>
            {members.map((member) => (
              <option key={member.id} value={member.name}>
                {member.name}
              </option>
            ))}
          </select>
        </div>

        {/* Submit and Cancel Buttons */}
        <button type="submit">Submit</button>
        <button type="button" onClick={onSwitchToDashboard}>
          Cancel
        </button>
      </form>
    </div>
  );
}

export default AddClassForm;
