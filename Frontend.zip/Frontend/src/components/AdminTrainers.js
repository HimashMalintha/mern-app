import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/AdminTrainers.css';

function AdminTrainers({ onSwitchToDashboard }) {
  const [search, setSearch] = useState('');
  const [trainers, setTrainers] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [selectedTrainer, setSelectedTrainer] = useState(null); // To store selected trainer details
  const [showPopup, setShowPopup] = useState(false); // To control popup visibility
  const [isEditing, setIsEditing] = useState(false); // To toggle between viewing and editing

  useEffect(() => {
    // Fetch trainers from the backend
    const fetchTrainers = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/trainers');
        setTrainers(response.data);
      } catch (err) {
        setError('Failed to fetch trainers from the backend.');
        console.error(err);
      }
    };

    fetchTrainers();
  }, []);

  const filteredTrainers = trainers.filter(
    (trainer) =>
      trainer.name.toLowerCase().includes(search.toLowerCase()) ||
      trainer.contactInfo.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this trainer?')) {
      try {
        await axios.delete(`http://localhost:5000/api/trainers/${id}`);
        setTrainers(trainers.filter((trainer) => trainer.id !== id));
        setSuccess('Trainer deleted successfully.');
        setError('');
      } catch (err) {
        setError('Failed to delete trainer.');
        console.error(err);
      }
    }
  };

  const handleEdit = (trainer) => {
    setSelectedTrainer(trainer);
    setIsEditing(true);
    setShowPopup(true);
  };

  const handleView = (trainer) => {
    setSelectedTrainer(trainer);
    setIsEditing(false);
    setShowPopup(true);
  };

  const handleSave = async () => {
    try {
      await axios.put(`http://localhost:5000/api/trainers/${selectedTrainer.id}`, selectedTrainer);
      setTrainers(
        trainers.map((trainer) =>
          trainer.id === selectedTrainer.id ? { ...trainer, ...selectedTrainer } : trainer
        )
      );
      setSuccess('Trainer updated successfully.');
      setError('');
      setShowPopup(false);
    } catch (err) {
      setError('Failed to update trainer.');
      console.error(err);
    }
  };

  const closePopup = () => {
    setShowPopup(false);
    setSelectedTrainer(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSelectedTrainer({ ...selectedTrainer, [name]: value });
  };

  return (
    <div className="admin-trainers-container">
      <main className="dashboard-content">
        <header className="dashboard-header">
          <h1>Trainers</h1>
          <p>
            Total Trainers: <span className="total-trainers">{trainers.length}</span>
          </p>
          <input
            type="text"
            placeholder="Search trainers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="search-input"
          />
          {/* Button to navigate back to AdminDashboard */}
          <button className="back-button" onClick={onSwitchToDashboard}>
            Back to Dashboard
          </button>
        </header>

        {success && <p className="success-message">{success}</p>}
        {error && <p className="error-message">{error}</p>}

        <section className="trainers-list">
          {filteredTrainers.map((trainer) => (
            <div key={trainer.id} className="trainer-card">
              <p className="trainer-name">Name: {trainer.name}</p>
              <p className="trainer-contact">Contact: {trainer.contactInfo}</p>
              <div className="action-buttons">
                <button className="edit-button" onClick={() => handleEdit(trainer)}>
                  Edit
                </button>
                <button className="view-button" onClick={() => handleView(trainer)}>
                  View
                </button>
                <button className="delete-button" onClick={() => handleDelete(trainer.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))}
        </section>
      </main>

      {/* Popup for Viewing/Editing Trainer Details */}
      {showPopup && selectedTrainer && (
        <div className="popup-overlay">
          <div className="popup-box">
            <h2>{isEditing ? 'Edit Trainer' : 'Trainer Details'}</h2>
            <div className="form-group">
              <label>Name:</label>
              {isEditing ? (
                <input
                  type="text"
                  name="name"
                  value={selectedTrainer.name}
                  onChange={handleChange}
                />
              ) : (
                <p>{selectedTrainer.name}</p>
              )}
            </div>
            <div className="form-group">
              <label>Contact:</label>
              {isEditing ? (
                <input
                  type="text"
                  name="contactInfo"
                  value={selectedTrainer.contactInfo}
                  onChange={handleChange}
                />
              ) : (
                <p>{selectedTrainer.contactInfo}</p>
              )}
            </div>
            <div className="form-group">
              <label>Specialty:</label>
              {isEditing ? (
                <input
                  type="text"
                  name="specialty"
                  value={selectedTrainer.specialty || ''}
                  onChange={handleChange}
                />
              ) : (
                <p>{selectedTrainer.specialty || 'N/A'}</p>
              )}
            </div>
            <div className="form-group">
              <label>Assigned Classes:</label>
              {isEditing ? (
                <textarea
                  name="assignedClasses"
                  value={selectedTrainer.assignedClasses || ''}
                  onChange={handleChange}
                ></textarea>
              ) : (
                <p>{selectedTrainer.assignedClasses || 'N/A'}</p>
              )}
            </div>
            {isEditing ? (
              <button className="save-button" onClick={handleSave}>
                Save
              </button>
            ) : null}
            <button className="close-button" onClick={closePopup}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminTrainers;
