import React, { useState } from 'react';
import axios from 'axios';
import '../styles/AddTrainerForm.css';

function AddTrainerForm({ onSwitchToDashboard }) {
  const [name, setName] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [assignedClasses, setAssignedClasses] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const trainerData = {
      name,
      specialty,
      assignedClasses,
      contactInfo,
    };

    try {
      // Send data to the backend
      const response = await axios.post('http://localhost:5000/api/trainers', trainerData);

      setSuccess(response.data.message);
      setError('');
      setName('');
      setSpecialty('');
      setAssignedClasses('');
      setContactInfo('');

      // Redirect back to the dashboard after 2 seconds
      setTimeout(onSwitchToDashboard, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add trainer.');
    }
  };

  return (
    <div className="add-trainer-form-container">
      <form className="add-trainer-form" onSubmit={handleSubmit}>
        <h2>Add Trainer</h2>
        {success && <p className="success-message">{success}</p>}
        {error && <p className="error-message">{error}</p>}
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Specialty</label>
          <input
            type="text"
            value={specialty}
            onChange={(e) => setSpecialty(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Assigned Classes</label>
          <input
            type="text"
            value={assignedClasses}
            onChange={(e) => setAssignedClasses(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Contact Information</label>
          <input
            type="text"
            value={contactInfo}
            onChange={(e) => setContactInfo(e.target.value)}
            required
          />
        </div>
        <button type="submit">Submit</button>
        <button type="button" onClick={onSwitchToDashboard}>
          Cancel
        </button>
      </form>
    </div>
  );
}

export default AddTrainerForm;
