// Import the functions you need from the SDKs
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC3nemY2Rqa1Ho-6TUFv2JJJBJUWp4vIVY",
  authDomain: "gymmanagement-52ba9.firebaseapp.com",
  projectId: "gymmanagement-52ba9",
  storageBucket: "gymmanagement-52ba9.appspot.com",
  messagingSenderId: "403495911602",
  appId: "1:403495911602:web:a0fdade4c70552d94889ab",
  measurementId: "G-7S4C8SFE4D",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Initialize Firestore
const db = getFirestore(app);

export { app, analytics, db }; // Export Firestore instance
