import React, { useState } from 'react';
import AdminDashboard from './components/AdminDashboard';
import AddPlanForm from './components/AddPlanForm';
import AddTrainerForm from './components/AddTrainerForm';
import AddMemberForm from './components/AddMemberForm';
import TrainerDashboard from './components/TrainerDashboard'; // Import TrainerDashboard component
import MemberDashboard from './components/MemberDashboard'; // Import MemberDashboard component
import Login from './components/Login';
import SignUp from './components/SignUp';
import LoginSignUp from './components/LoginSignUp';
import './index.css';

function App() {
  const [currentPage, setCurrentPage] = useState('loginSignUp'); // Default page is LoginSignUp
  const [userRole, setUserRole] = useState(null); // Track user role

  const handleLoginSuccess = (role) => {
    setUserRole(role);
    if (role === 'admin') {
      setCurrentPage('dashboard');
    } else if (role === 'trainer') {
      setCurrentPage('trainerDashboard');
    } else if (role === 'member' || !role) {
      // Navigate to MemberDashboard if role is missing or not recognized
      setCurrentPage('memberDashboard');
    } else {
      setCurrentPage('userDashboard'); // Default for other roles
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'loginSignUp':
        return (
          <LoginSignUp
            onSwitchToLogin={() => setCurrentPage('login')}
            onSwitchToSignUp={() => setCurrentPage('signup')}
          />
        );
      case 'login':
        return (
          <Login
            onSwitchToSignUp={() => setCurrentPage('signup')}
            onLoginSuccess={handleLoginSuccess}
          />
        );
      case 'signup':
        return <SignUp onSwitchToLogin={() => setCurrentPage('login')} />;
      case 'dashboard':
        return (
          <AdminDashboard
            onSwitchToAddPlan={() => setCurrentPage('addPlanForm')}
            onSwitchToAddClasses={() => setCurrentPage('addClassesForm')}
            onSwitchToAddTrainers={() => setCurrentPage('addTrainerForm')}
            onSwitchToAddMembers={() => setCurrentPage('addMembersForm')}
          />
        );
      case 'trainerDashboard':
        return (
          <TrainerDashboard
            onSwitchToLogin={() => setCurrentPage('login')}
          />
        );
      case 'memberDashboard':
        return (
          <MemberDashboard
            onSwitchToLogin={() => setCurrentPage('login')}
          />
        );
      case 'addMembersForm':
        return <AddMemberForm onSwitchToDashboard={() => setCurrentPage('dashboard')} />;
      case 'addTrainerForm':
        return <AddTrainerForm onSwitchToDashboard={() => setCurrentPage('dashboard')} />;
      case 'addPlanForm':
        return <AddPlanForm onSwitchToDashboard={() => setCurrentPage('dashboard')} />;
      default:
        return <h1>Page Not Found</h1>;
    }
  };

  return <div className="App">{renderPage()}</div>;
}

export default App;
