const express = require('express');
const cors = require('cors');
const packageRoutes = require('./routes/packageRoutes'); // Import package routes
const memberRoutes = require('./routes/clientRoutes'); // Import member routes
const trainerRoutes = require('./routes/trainerRoutes'); // Import trainer routes
const statsRoutes = require('./routes/statsRoutes'); // Import stats routes

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/packages', packageRoutes); // For package-related operations
app.use('/api/members', memberRoutes); // For member-related operations
app.use('/api/trainers', trainerRoutes); // For trainer-related operations (CRUD)
app.use('/api/stats', statsRoutes); // For statistics-related operations

// Health Check Endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ message: 'API is running and healthy!' });
});

// 404 Error Handling Middleware for Undefined Routes
app.use((req, res, next) => {
  res.status(404).json({ message: 'Route not found' });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'An internal server error occurred' });
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
