const { admin, db } = require('../firebaseConfig');

const signup = async (req, res) => {
  const { email, password, role } = req.body;

  try {
    // Create user in Firebase Authentication
    const user = await admin.auth().createUser({ email, password });

    // Add user to Firestore
    await db.collection('users').doc(user.uid).set({
      email,
      role,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    res.status(201).send({ message: 'User created successfully', user });
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
};

module.exports = { signup };

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Note: Firebase Admin SDK does not provide login capabilities directly. You should use Firebase client SDK on the frontend.

    // Simulate token generation
    const token = "MockedTokenForLogin"; // Replace this with real token logic from frontend
    res.status(200).send({ token });
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
};

module.exports = { signup, login };
