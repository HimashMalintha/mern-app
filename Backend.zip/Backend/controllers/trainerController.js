const { db } = require('../firebaseAdmin');

// Add a new trainer
const createTrainer = async (req, res) => {
  const { name, specialty, assignedClasses, contactInfo } = req.body;

  try {
    const docRef = await db.collection('trainers').add({
      name,
      specialty,
      assignedClasses,
      contactInfo,
      createdAt: new Date().toISOString(),
    });
    res.status(200).send({ message: 'Trainer added successfully!', id: docRef.id });
  } catch (error) {
    res.status(500).send({ message: 'Failed to add trainer.', error: error.message });
  }
};

// Get all trainers
const getTrainers = async (req, res) => {
  try {
    const trainersSnapshot = await db.collection('trainers').get();
    const trainers = trainersSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    res.status(200).send(trainers);
  } catch (error) {
    res.status(500).send({ message: 'Failed to fetch trainers.', error: error.message });
  }
};

// Update a trainer
const updateTrainer = async (req, res) => {
  const { id } = req.params;
  const { name, specialty, assignedClasses, contactInfo } = req.body;

  try {
    await db.collection('trainers').doc(id).update({
      name,
      specialty,
      assignedClasses,
      contactInfo,
    });
    res.status(200).send({ message: 'Trainer updated successfully.' });
  } catch (error) {
    res.status(500).send({ message: 'Failed to update trainer.', error: error.message });
  }
};

// Delete a trainer
const deleteTrainer = async (req, res) => {
  const { id } = req.params;

  try {
    await db.collection('trainers').doc(id).delete();
    res.status(200).send({ message: 'Trainer deleted successfully.' });
  } catch (error) {
    res.status(500).send({ message: 'Failed to delete trainer.', error: error.message });
  }
};

module.exports = {
  createTrainer,
  getTrainers,
  updateTrainer,
  deleteTrainer,
};
