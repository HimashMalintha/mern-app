const { db } = require('../firebaseAdmin'); // Import Firestore instance

// Controller to add a new member
const addMember = async (req, res) => {
  const { name, membershipType, status, joinDate } = req.body;

  try {
    const docRef = await db.collection('members').add({
      name,
      membershipType,
      status,
      joinDate,
      createdAt: new Date().toISOString(),
    });
    res.status(200).send({ message: 'Member added successfully!', id: docRef.id });
  } catch (error) {
    res.status(500).send({ message: 'Failed to add member.', error: error.message });
  }
};

// Controller to fetch all members
const getAllMembers = async (req, res) => {
  try {
    const membersSnapshot = await db.collection('members').get();
    const members = membersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.status(200).send(members);
  } catch (error) {
    res.status(500).send({ message: 'Failed to fetch members.', error: error.message });
  }
};

module.exports = {
  addMember,
  getAllMembers,
};
