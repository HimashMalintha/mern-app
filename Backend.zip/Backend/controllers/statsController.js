const { db } = require('../firebaseAdmin'); // Import Firestore instance

// Get Member Count
const getMemberCount = async (req, res) => {
  try {
    const membersSnapshot = await db.collection('members').get();
    const count = membersSnapshot.size;
    res.status(200).json({ count });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch member count' });
  }
};

// Get Trainer Count
const getTrainerCount = async (req, res) => {
  try {
    const trainersSnapshot = await db.collection('trainers').get();
    const count = trainersSnapshot.size;
    res.status(200).json({ count });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch trainer count' });
  }
};

module.exports = {
  getMemberCount,
  getTrainerCount,
};
