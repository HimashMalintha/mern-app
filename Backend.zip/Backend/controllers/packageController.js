const { db } = require('../firebaseAdmin'); // Import Firestore instance

// Create a new package
const createPackage = async (req, res) => {
  const { planName, price, duration, description } = req.body;

  try {
    const docRef = await db.collection('packages').add({
      planName,
      price,
      duration,
      description,
      createdAt: new Date().toISOString(),
    });
    res.status(200).json({ message: 'Package created successfully!', id: docRef.id });
  } catch (error) {
    res.status(500).json({ message: 'Failed to create package.', error: error.message });
  }
};

// Get all packages
const getPackages = async (req, res) => {
  try {
    const snapshot = await db.collection('packages').get();
    const packages = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    res.status(200).json(packages);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch packages.', error: error.message });
  }
};

// Export functions
module.exports = {
  createPackage,
  getPackages,
};
