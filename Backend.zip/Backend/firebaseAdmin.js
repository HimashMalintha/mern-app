const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
const serviceAccount = require('./serviceAccountKey.json'); // Download your service account key file from Firebase Console

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://gymmanagement-52ba9.firebaseio.com",
});

const db = admin.firestore();

module.exports = { db };
