const express = require('express');
const { getMemberCount, getTrainerCount } = require('../controllers/statsController');

const router = express.Router();

// Routes for Member and Trainer Counts
router.get('/members', getMemberCount);
router.get('/trainers', getTrainerCount);

module.exports = router;
