const express = require('express');
const router = express.Router();
const { addMember, getAllMembers } = require('../controllers/clientController'); // Import member controllers

// Route to add a new member
router.post('/', addMember);

// Route to fetch all members
router.get('/', getAllMembers);

module.exports = router;
