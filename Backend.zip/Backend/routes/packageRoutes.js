const express = require('express');
const { createPackage, getPackages } = require('../controllers/packageController');

const router = express.Router();

// Route to create a new package
router.post('/', createPackage);

// Route to get all packages
router.get('/', getPackages);

module.exports = router;
