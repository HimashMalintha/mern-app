const express = require('express');
const router = express.Router();
const { signup, login } = require('../controllers/authController');
const verifyToken = require('../middleware/authMiddleware');

router.post('/signup', signup);
router.post('/login', login);
router.get('/protected-route', verifyToken, (req, res) => {
  res.send({ message: 'You are authorized', user: req.user });
});

module.exports = router;
