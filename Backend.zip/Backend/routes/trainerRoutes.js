const express = require('express');
const { createTrainer, getTrainers, updateTrainer, deleteTrainer } = require('../controllers/trainerController');

const router = express.Router();

// Routes for trainer management
router.post('/', createTrainer); // Route for adding a trainer
router.get('/', getTrainers); // Route for fetching all trainers
router.put('/:id', updateTrainer); // Route for updating a trainer by ID
router.delete('/:id', deleteTrainer); // Route for deleting a trainer by ID

module.exports = router;
